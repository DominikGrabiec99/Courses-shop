const { coursesData } = require('./courses');

const usersData = [
  {
    accessLevel: 0,
    budget: 150,
    basket: [],
    courses: [
      coursesData[0].id,
      coursesData[1].id,
      coursesData[2].id,
    ],
    name: 'User',
    surname: 'User',
    login: 'User',
    password: 'User',
  },
  {
    accessLevel: 1,
    budget: 1000000,
    basket: [],
    courses: [
      coursesData.map(course => course.id)
    ],
    name: 'admin',
    surname: 'admin',
    login: 'admin',
    password: 'admin',
  }
];

exports.postUser = (request, response, next) => {
  try {
    const { login, password } = request.body;

    const user = usersData.find(u => u.login === login);
    if (!user) {
      response.status(404).json({
        message: 'Użytkownik o podanym loginie nie istnieje',
      });
  
      return;
    }

    const isPasswordCorrect = user.password === password;
    if (!isPasswordCorrect) {
      response.status(401).json({
        message: 'Hasło lub login się nie zgadza',
      });

      return;
    }

    response.status(200).json({
      user,
    });
  } catch (error) {
    response.status(500).json({
      error,
      message: 'Oops! Coś poszło nie tak, przy metodzie POST w endpointcie /users',
    });
  }
};

exports.addUser = (request, response, next) => {
  try {
    const { accessLevel, budget, courses, login, password, name, surname, basket } = request.body;
    if ( !login || !password || !budget || !name || !surname) {
      response.status(400).json({
        message: 'Nie podano wszystkich wymaganych informacji',
      });

      return;
    }

    const isUserExist = usersData.some(({login: currentLogin}) => currentLogin === login);
    if (isUserExist) {
      response.status(409).json({
        message: `Istnieje już w bazie użytkownik o loginie: ${login}`,
      });

      return;
    }

    const newUser = {
        accessLevel,
        budget,
        courses,
        login,
        password,
        basket
    };

    usersData.push(newUser);

    response.status(201).json({
      users: usersData
    });
  } catch (error) {
    response.status(500).json({
      error,
      message: 'Oops! Coś poszło nie tak, przy metodzie ADD w endpointcie /users'
    });
  }
};

//exports.patchUser = (request, response, next) => {
//  try {
//    const { login, courseId } = request.body;
//
//    const course = coursesData.find(course => course.id === courseId);
//    const user = usersData.find(user => user.login === login);
//
//    if (!course) {
//      response.status(404).json({
//        message: 'Nie znaleziono kursu o podanym Id',
//      });
//
//      return;
//    } else if (!user) {
//      response.status(404).json({
//        message: 'Nie znaleziono uzytkownika o podanym loginie',
//      });
//
//      return;
//    }
//
//    const hasUserCourseAlready = user.courses.some(id => id === courseId);
//    if (hasUserCourseAlready) {
//      response.status(200).json({
//        user,
//      });
//
//      return;
//    }
//
//    const hasUserEnoughtMoney = user.budget - course.price >= 0;
//    if (!hasUserEnoughtMoney) {
//      response.status(403).json({
//        message: 'Uzytkownik nie posiada wystarczających funduszy',
//      });
//
//      return;
//    }
//
//    user.budget = Number((user.budget - course.price).toFixed(2));
//    user.courses.push(courseId);
//    response.status(202).json({
//      user,
//    });
//  } catch (error) {
//    response.status(500).json({
//      error,
//      message: 'Oops! Coś poszło nie tak, przy metodzie PATCH w endpointcie /users',
//    });
//  }
//};

exports.patchUser = (request, response, next) => {
  try {
    const { login, courseId, isAddToBasket } = request.body;
    const user = usersData.find(user => user.login === login);
      
    if(isAddToBasket === "toBasket") {
        
    const course = coursesData.find(course => course.id === courseId);

    if (!course) {
      response.status(404).json({
        message: 'Nie znaleziono kursu o podanym Id',
      });

      return;
    } else if (!user) {
      response.status(404).json({
        message: 'Nie znaleziono uzytkownika o podanym loginie',
      });

      return;
    }

    const hasUserCourseAlready = user.basket.some(id => id === courseId);
    if (hasUserCourseAlready) {
      response.status(200).json({
        user,
      });

      return;
    }
      
      const hasUserCourseAlready2 = user.courses.some(id => id === courseId);
    if (hasUserCourseAlready2) {
      response.status(201).json({
        user,
      });

      return;
    }

    user.basket.push(courseId);
    response.status(202).json({
      user,
    });
        
    } else if (isAddToBasket === "buy") {
        if (!user) {
      response.status(404).json({
        message: 'Nie znaleziono uzytkownika o podanym loginie',
      });

      return;
    }
    
    user.courses = [...user.courses, ...user.basket];
    user.basket = [];
    response.status(202).json({
      user,
    });
        
    } else { 
        
    if (!user) {
      response.status(404).json({
        message: 'Nie znaleziono uzytkownika o podanym loginie',
      });

      return;
    }
        
    const indexCourse = user.basket.findIndex(course => course === courseId)
    user.basket.splice(indexCourse, 1)
        
    response.status(202).json({
      user,
    }); 
        
    }
  } catch (error) {
    response.status(500).json({
      error,
      message: 'Oops! Coś poszło nie tak, przy metodzie PATCH w endpointcie /users',
    });
  }
};


//exports.patchUser = (request, response, next) => {
//  try {
//    const { login, courseId } = request.body;
//
//    const course = coursesData.find(course => course.id === courseId);
//    const user = usersData.find(user => user.login === login);
//
//    if (!course) {
//      response.status(404).json({
//        message: 'Nie znaleziono kursu o podanym Id',
//      });
//
//      return;
//    } else if (!user) {
//      response.status(404).json({
//        message: 'Nie znaleziono uzytkownika o podanym loginie',
//      });
//
//      return;
//    }
//
//    const hasUserCourseAlready = user.basket.some(id => id === courseId);
//    if (hasUserCourseAlready) {
//      response.status(200).json({
//        user,
//      });
//
//      return;
//    }
//      
//      const hasUserCourseAlready2 = user.courses.some(id => id === courseId);
//    if (hasUserCourseAlready2) {
//      response.status(201).json({
//        user,
//      });
//
//      return;
//    }
//
//    user.basket.push(courseId);
//    response.status(202).json({
//      user,
//    });
//  } catch (error) {
//    response.status(500).json({
//      error,
//      message: 'Oops! Coś poszło nie tak, przy metodzie PATCH w endpointcie /users',
//    });
//  }
//};