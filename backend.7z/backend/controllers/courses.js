const { v4: uuid } = require('uuid');

const coursesData = [
  {
    authors: ['Bartłomiej Borowczyk'],
    id: uuid(),
    img: 'https://img-c.udemycdn.com/course/240x135/1673856_ff13_5.jpg?Expires=1624950741&Signature=d8gQhmS~GcFSa8s-Fz4FQviup1iIp6orF6Dbg9NYaChwofIlQCGRPPYXeU~QUBHEuvqmoLxDTFMVdZtipuvijifLihZ91EQdy4PRM714r7rwVG5UPvKTlceJlM3FKhjWX1DGL8KSCwpm1H0FoMxi5L~Ijt5usqAYtwvgMYaX56gF6-bYO5cQBm6xM7mws5ful4ERN9hiLmVojJUA23z1uCo7~xrRAlwodaB-h99xp5Gu9vTReUUuLlQ0uAl4KErOZocytQQv2ljlC05gsi0xQ45Lo-O18XYi724ua4qTEZDyZPKvOFJ4MQeJcSzsU3gRRC1E5TV7hcqdQ8TqUfoohQ__&Key-Pair-Id=APKAITJV77WS5ZT7262A',
    price: 69.99,
    title: 'Web developer od podstaw w 15 dni',
  },
  {
    authors: ['Bartłomiej Borowczyk'],
    id: uuid(),
    img: 'https://img-c.udemycdn.com/course/240x135/1844944_e2f8_3.jpg?Expires=1624950861&Signature=VUW389bPlKZLzoF5KKDhM6kTOII2CGD06CBUagEEyxBp-z9yfnJByuIE2gZmscTkgAjrQFDMM7JYkat6KpCxCwi8cPBqxc0aJLt3OyAZedx-k7dAld1niJObmzBQrqIp4lT91OW74z6UzD~rTQ92x8PtEgSXQPh6~Zz8VKshwgzDCulnYVOxYh6MYqRkhpMVBsApCRgyAkilCK5E4~NrCzkdDdIV2EBk8SB6DlMMIKHCbV3ZiUfYorjlXuXzbZSlwMgGBqwmyjxev0SJyb43jN3Bif79TbjyWRanj-i~GFZcsSKEyCpQSUtmqq6JfAG7Tn~jSqJ1zi4LmLhVCYZdew__&Key-Pair-Id=APKAITJV77WS5ZT7262A',
    price: 69.99,
    title: 'Zaawansowany front-end w 15 dni',
  },
  {
    authors: ['Bartłomiej Borowczyk'],
    id: uuid(),
    img: 'https://img-c.udemycdn.com/course/240x135/1916892_601a.jpg?Expires=1624950943&Signature=kQqNtQFRv~D4S5wgGsgoPBQ--KMqE3F-eHWFU2SAG6oGm5VCgsqL1QGn3oQFYrSR-PEboHxwuRERwUdSLQVsUjNgCk2dh5t-eHmHqQJY6BPvPIVRLV531crgg-3hu4xzvJbkYqCxT2ywjbHL-DclTRocVe799PNEYXfSSmVxM9fDb2HgXnHE6SMlI0ER8QzpvwELjUfCoAudLC02cM-dkYytuBXu77UW6HnkorZasKqBqs42Tu3zYloyG3hCNWayCuTDTaBJI--iI0cDx-QyjltDal9UzwDgPKACwkYQLYRi817n4FxQsp~bd11xlnmjNwD7KbIE8W7MBgggvtMuNA__&Key-Pair-Id=APKAITJV77WS5ZT7262A',
    price: 69.99,
    title: 'Programowanie w JavaScript',
  },
  {
    authors: ['Bartłomiej Borowczyk', 'Mateusz Domański'],
    id: uuid(),
    img: 'https://img-c.udemycdn.com/course/240x135/2049385_9a8c.jpg?Expires=1624951047&Signature=kiirGBi9tt1d3zex03eS7Sql0lGJbD~VZx1p-jwqicaUfiQ6VToj4WuMXnxPnCKLDqJOs7mcgh~q3~CSgT4eSofTlA1XqJDfJcZhTY5Eq~EWzQuEjrJ4YgVH1sAm55wT8AORdPH9ZFldb9cMVQSAel1-wICEQeNaoNK3-tDGiXYlyQYwFBF2ENpdCeTbuFUyCxST1eJmuwQnByy9NbMqI1uAs~MA6i70d42kWGuVo5LyHgXZtL4GOmRC9GJ0nnWktsCW4G5j5z1IsxQg3ZGLqwmVagPiJo4NnNiRcaJmYZNE2FZWOvLqzgm1pMvICKmUncKWKjkzphKfmCy5jB-c8w__&Key-Pair-Id=APKAITJV77WS5ZT7262A',
    price: 69.99,
    title: 'React od podstaw - teoria i praktyka',
  },
  {
    authors: ['Bartłomiej Borowczyk'],
    id: uuid(),
    img: 'https://img-c.udemycdn.com/course/240x135/2330558_0de2_2.jpg?Expires=1624951307&Signature=c-y--vtWytLlZqR~nA2ihEoXTHa7DW2l8b~Lo7uAr1nVZxgR098NO6ELtP6vCrhQ1lYGaDSDAnrGq6d5dmAE8qr9HhzGDUOesisUWTW-AASdd4EgjiHJG9~E0K~zkPgkW~rX6RdBPNwExasOQNGW9x~B3sNfH3jEjKQcjbOTqIb6aa2a2oOx1T6pS5Ix~qaJhvKP7bQZfbP8IcRbhfXigkPmRA-2zWz~2F4KzPG7gRIJZe-4hAKvj8xQHzp636VyBVqrdow7A0lED2L8-CQ2egDQNVXBGlENbtm5JgsdEpwCBmQ9MIPargOl4VB51~MJcNLNVDnYrg4HOkkUxKMi8Q__&Key-Pair-Id=APKAITJV77WS5ZT7262A',
    price: 69.99,
    title: 'Backend - Node.js, Express i MongoDB',
  },
  {
    authors: ['Bartłomiej Borowczyk'],
    id: uuid(),
    img: 'https://img-c.udemycdn.com/course/240x135/2331806_b90c_2.jpg?Expires=1624951376&Signature=FNVMfB9bmxMLF4WYQ6SAFdw-uOcNE5IjViEE7S-pANOIUox2bddmqVoUl8Hkc9Hly2~gaF0e47aGiFzf9JHJScX0rzxrjMxX1pgq4RxU9tj4czXcknEuQerZxxWdfZ~45UOsyc8lnhFdN0srrfaZy8m6CfQqfDsY1T1HpUJrzH9D7utoCgPkgAVBt7iolkBTRpCWmiiyJinGF8o01Wo5EF~OUTwiR2eAbFxqiv-PWodFVNJKzwTe07y35U~nnpz5XTQjb49ONrogaTUFUtm25NhJRGIXg669Os-GjG9LPkh4o-G771~jO12snPbJMrCEFzMHNQ89MfIMFfiPKvxX3w__&Key-Pair-Id=APKAITJV77WS5ZT7262A',
    price: 69.99,
    title: '(Zaawansowane) Projekty w CSS i JavaScript',
  },
  {
    authors: ['Bartłomiej Borowczyk'],
    id: uuid(),
    img: 'https://img-c.udemycdn.com/course/240x135/2258904_bd66_4.jpg?Expires=1624951216&Signature=IUbj6zQCT7bHFfqxETkSCnE6MCPGZBcnNGEsH69LjkLfIUy0MoWv8gRAQmJJSPoZvPkv5267efM~kyPXodv~5ENPmWGfdVYGSx33IuTnaX4-bPJCpkMs3YNCrjeWf2p0YaZtHdCvjnMnEtmJhSdxfVS5lYITgPNCsb8QGcsSJpjieMPsaudirmEpyI6i29mXgJp9Eh7iot4AbGjwc4YCBfs~vI2bPzzHrjQRU7mmAzLJ9-PD9ofaQzZStnsP~HvHM5e03VL5Eh0uaW2KPjJCZ2TrjRXymuiJZv~~8Mh6grFb8-LYww4-zcVdKHu-g5ATrbqvTialSw9L54gqp2UiqA__&Key-Pair-Id=APKAITJV77WS5ZT7262A',
    price: 0,
    title: 'Wprowadzenie do Git i GitHub',
  },
  {
    authors: ['Bartłomiej Borowczyk', 'Mateusz Domański', 'Michał Dziedziński', 'Kacper Sieradziński'],
    id: uuid(),
    img: 'https://img-c.udemycdn.com/course/240x135/3428814_eee3_4.jpg?Expires=1624952923&Signature=ewpsB-UAGbGvt6tcxZ~ro1GTgzcCFUsI0~XN63sQNO44W2jO26jpvsH3vnlg8BvSAvpw07jacmdB91wMXmzRwRyrn9VmBNqEidT3uBsB4hxqAtk8PDysnufpukAEgZGsl1maRp4L96eGxoaQ6PEX9Rmfym-SXnTY4bF5fpZpBhE3UdGBHH3UnhHbhkU67YYLjYeZfvsR6yfeOqLQdhvUu6B5J~D6u5jZyp7d2klD-K6eq8uIWrRaNMt5zh6cP3vTpGzUKlmW79j~gBMoENoLob4Cnf-6nMuXvivnr5ScAz~5zp2K1CRxeNqLrWECiP4nwRY9QlJotEcPTa36tFyyZw__&Key-Pair-Id=APKAITJV77WS5ZT7262A',
    price: 69.99,
    title: 'Nauka JavaScript - obiektowość'
  }
];

exports.getCourses = (request, response, next) => {
  try {
    response.status(200).json({
      courses: coursesData
    });
  } catch (error) {
    response.status(500).json({
      error,
      message: 'Oops! Coś poszło nie tak, przy metodzie GET w endpointcie /courses',
    });
  }
};

exports.getCourse = (request, response, next) => {
  try {
    const { id } = request.params;
    const courseToSend = coursesData.find(course => course.id === id);

    if (!courseToSend) {
      response.status(404).json({
        message: 'Nie znaleziono kursu o podanym id',
      });
      
      return;
    }

    response.status(200).json({
      course: courseToSend, 
    });
  } catch (error) {
    response.status(500).json({
      error,
      message: 'Oops! Coś poszło nie tak, przy metodzie GET w endpointcie /courses/:id',
    })
  }
};

exports.postCourse = (request, response, next) => {
  try {
    const { authors, img, price, title } = request.body;
    if ( !authors || !price || !title ) {
      response.status(400).json({
        message: 'Nie podano wszystkich wymaganych informacji',
      });

      return;
    }

    const isCourseExist = coursesData.some(({title: currentTitle}) => currentTitle === title);
    if (isCourseExist) {
      response.status(409).json({
        message: `Istnieje już w bazie kurs ${title}`,
      });

      return;
    }

    const newCourse = {
      authors: authors,
      id: uuid(),
      img,
      price,
      title,
    };

    coursesData.push(newCourse);

    response.status(201).json({
      courses: coursesData
    });
  } catch (error) {
    response.status(500).json({
      error,
      message: 'Oops! Coś poszło nie tak, przy metodzie POST w endpointcie /courses'
    });
  }
};

exports.putCourse = (request, response, next) => {
  try {
    const { authors, id, price, title } = request.body;
    if (!authors || !id || !price || !title) {
      response.status(400).json({
        message: 'Nie podano wszystkich wymaganych informacji',
      });

      return;
    }

    const indexCourseToUpdate = coursesData.findIndex(course => course.id === id);
    if (indexCourseToUpdate === -1) {
      response.status(404).json({
        message: 'Nie znaleziono kursu o podanym id',
      });
      
      return;
    }
    
    
    coursesData.splice(indexCourseToUpdate, 1, request.body);

    response.status(202).json({
      courses: coursesData
    });
  } catch (error) {
    response.status(500).json({
      error,
      message: 'Oops! Coś poszło nie tak, przy metodzie PUT w endpointcie /courses'
    });
  }
};

exports.deleteCourse = (request, response, next) => {
  try {
    const { id } = request.params;

    console.log(id);
    const indexCourseToDelete = coursesData.findIndex(course => course.id === id);

    if (indexCourseToDelete === -1) {
      response.status(404).json({
        message: 'Nie znaleziono kursu o podanym id',
      });
      
      return;
    }

    coursesData.splice(indexCourseToDelete, 1);
    response.status(200).end();
  } catch (error) {
    response.status(500).json({
      error,
      message: 'Oops! Coś poszło nie tak, przy metodzie DELETE w endpointcie /courses/:id',
    });
  }
};

exports.coursesData = coursesData;