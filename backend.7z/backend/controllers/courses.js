const { v4: uuid } = require('uuid');

const coursesData = [
  {
    authors: ['Bartłomiej Borowczyk'],
    id: uuid(),
    img: 'https://img-c.udemycdn.com/course/240x135/1673856_ff13_5.jpg?Expires=1624950741&Signature=d8gQhmS~GcFSa8s-Fz4FQviup1iIp6orF6Dbg9NYaChwofIlQCGRPPYXeU~QUBHEuvqmoLxDTFMVdZtipuvijifLihZ91EQdy4PRM714r7rwVG5UPvKTlceJlM3FKhjWX1DGL8KSCwpm1H0FoMxi5L~Ijt5usqAYtwvgMYaX56gF6-bYO5cQBm6xM7mws5ful4ERN9hiLmVojJUA23z1uCo7~xrRAlwodaB-h99xp5Gu9vTReUUuLlQ0uAl4KErOZocytQQv2ljlC05gsi0xQ45Lo-O18XYi724ua4qTEZDyZPKvOFJ4MQeJcSzsU3gRRC1E5TV7hcqdQ8TqUfoohQ__&Key-Pair-Id=APKAITJV77WS5ZT7262A',
    price: 69.99,
    language: 'Polski',
    date: '09.2018',
    level: 'Średnio-zaawansowany',
    hours: 32,
    lectures: 210,
    title: 'Web developer od podstaw w 15 dni',
    shortDiscription: `Zdobądź solidne podstawy HTML i CSS i zyskaj umiejętności potrzebne do samodzielnego tworzenia nowoczesnych stron www.`,
    description: [`Podczas tego kursu opanujesz techniki, które pozwolą Ci tworzyć proste, ale fajne strony internetowe, które będą dobrze wyglądać również na urządzeniach mobilnych - pod koniec kursu zbudujesz taką stronę-wizytówkę. Nauczysz się od podstaw tworzyć strukturę strony w HTML i stylować ją przy pomocy CSS. Poznasz również przydatne narzędzia usprawniające pracę związaną z tworzeniem stron. Zrobimy bardzo dużo w kierunku zostania przez Ciebie dobrym web developerem`

    ,`Po opanowaniu podstaw HTML-a skupimy się na wyglądzie strony a więc CSS-ie. Zaczniemy od fundamentów, takich jak style domyślne, tworzenie własnych stylów, kaskadowość i dziedziczenie, następnie zajmiemy się najważniejszymi właściwościami CSS związanymi z wyglądem, pozycjonowaniem (ustawianiem pozycji) i przekształcaniem elementów na stronie.` 

    ,`Przekażę Ci także praktyczne wskazówki związane z optymalizacją strony pod kątem wyszukiwarek internetowych, tworzeniem mockupów, źródłami zdjęć na stronę czy inspiracji do projektów. Zajmiemy się zagadnieniem responsywności strony, czyli tym, jak jak za pomocą HTML i CSS zadbać o to, by wyświetlała się dobrze na ekranach o różnych rozdzielczościach.`

    ,`Zadania w kursie`

    ,`Nauka tworzenia stron czy programowania wymaga bardzo dużo praktyki, dlatego w tym kursie będę wymagał od Ciebie, byś robił(a) różne zadania, nie tylko oglądał(a) wideo, ale też pracował(a). Nie pomijaj zadań, MUSISZ je robić, jeśli chcesz osiągnąć efekty. Zachęcam Cię do obejrzenia przykładowych filmów z kursu, żeby zobaczyć, w jaki sposób skonstruowałam zadania.`  

    ,`Po opanowaniu wspomnianych wyżej fundamentów stworzymy od podstaw stronę-wizytówkę, na której możesz umieszczać swoje projekty, tworząc własne portfolio a także ją rozbudowywać. Będzie to dla Ciebie świetny trening, ale też podstawa do Twoich kolejnych projektów. Na koniec umieścimy stronę na hostingu i podepniemy do niej domenę.` 

    ,`Ile czasu musisz poświęcić na kurs? `

    ,`Kurs podzielony jest na sekcje-dni, z których każda wymaga poświęcenia 2-3 godzin dziennie. Zaplanowałem ten kurs jako 15-dniową ścieżkę, ale możesz się uczyć szybciej, możesz się uczyć wolniej, nie każdego dnia. Ogranicza Cię czas i chęci, choć przyznam, że wielkim sukcesem, Twoim sukcesem, byłoby, gdybyś zrobił(a) ten kurs rzeczywiście w 15 dni. Jeśli zdecydujesz się rozłożyć ten kurs na więcej niż 15 dni, to niech nie będzie to więcej niż 30 dni. Oczywiście nie ma przeszkód, by – jeśli masz czas i ochotę – robić np. 2 dni jednego dnia.`   

    ,`Kurs jako start do zostania web/front-end developerem`   

    ,`Kurs jest pierwszą częścią mojego programu „Od podstaw do pracy front-end developera”, obejmującego 6 etapów-kursów na Udemy. Opanowanie HTML i CSS stanowi pierwszy duży krok do pracy web/front-end developera i pozwala tworzyć strony internetowe. Jeśli chcesz rozpocząć swoją ścieżkę zawodową jako front-end developer, to zapraszam Cię do wspólnej nauki przez cały ten projekt. Jednak ten kurs stanowi jednocześnie samodzielną całość, która pozwala Ci opanować fundamenty CSS i HTML, tworzyć proste, fajne strony internetowe i umieszczać je w internecie.`],
    knowledge: ['Umieszczać stronę w internecie (hosting, domena).', 'Korzystać z narzędzi przydatnych w pracy web/front-end developera.', `W czasie kursu stworzysz własną stronę-wizytówkę, na której możesz umieszczać swoje projekty.`, `Tworzyć strony internetowe zgodne z aktualnymi standardami, zoptymalizowane pod kątem wyszukiwarek i dobrze wyglądające na urządzeniach mobilnych.`]
  },
  {
    authors: ['Bartłomiej Borowczyk'],
    id: uuid(),
    img: 'https://img-c.udemycdn.com/course/240x135/1844944_e2f8_3.jpg?Expires=1624950861&Signature=VUW389bPlKZLzoF5KKDhM6kTOII2CGD06CBUagEEyxBp-z9yfnJByuIE2gZmscTkgAjrQFDMM7JYkat6KpCxCwi8cPBqxc0aJLt3OyAZedx-k7dAld1niJObmzBQrqIp4lT91OW74z6UzD~rTQ92x8PtEgSXQPh6~Zz8VKshwgzDCulnYVOxYh6MYqRkhpMVBsApCRgyAkilCK5E4~NrCzkdDdIV2EBk8SB6DlMMIKHCbV3ZiUfYorjlXuXzbZSlwMgGBqwmyjxev0SJyb43jN3Bif79TbjyWRanj-i~GFZcsSKEyCpQSUtmqq6JfAG7Tn~jSqJ1zi4LmLhVCYZdew__&Key-Pair-Id=APKAITJV77WS5ZT7262A',
    price: 69.99,
    language: 'Polski',
    date: '05.2019',
    title: 'Zaawansowany front-end w 15 dni',
    level: 'Średnio-zaawansowany',
    hours: 52,
    lectures: 170,
    shortDiscription: `Naucz się tworzyć atrakcyjne strony internetowe z wykorzystaniem bardziej zaawansowanych technik CSS i JavaScript`,
    description: [`Ten kurs pomoże Ci uzyskać biegłość w posługiwaniu się kluczowymi właściwościami CSS a także sprawnie wykorzystywać JavaScript i jQuery w celu uatrakcyjnienia (ożywienia) tworzonego projektu. Nauczysz się korzystać z nowoczesnych, bardziej zaawansowanych technik i rozwiązań CSS, takich jak Flexbox czy CSS Animation. Poznasz też preprocesor Sass. Podczas kursu zrobimy mnóstwo projektów, np. galeria, slajder, modal/popup, menu hamburger, animacje, efekty związane z kliknięciem, najechaniem czy skrolowaniem strony.`

    ,`Kurs rekomendowany osobom, które uczyły się wcześniej same lub przeszły ze mną I etap nauki (kurs Web developer od podstaw w 15 dni), znają fundamenty HTML i CSS oraz są w stanie stworzyć samodzielnie prostą stronę internetową. Nie jest wymagana znajomość JavaScript.`

    ,`Ten kurs jest niezależnym projektem edukacyjnym, ale jest to jednocześnie drugi z 6 etapów w projekcie "Od podstaw do pierwszej pracy jako front-end developer". Kolejnym krokiem będzie pogłębienie znajomości JavaScript. Kurs ten pozwoli Ci uzyskać biegłość w posługiwaniu się CSS-em i poznać JavaScript w zakresie budowania layoutu i tworzenia efektów na stronie.`],
    knowledge: [`Tworzyć atrakcyjne strony internetowe z wykorzystaniem bardziej zaawansowanych technik CSS`,`Tworzyć layouty w oparciu o Flexbox i CSS Grid`,`Wykorzystywać JavaScript i jQuery do tworzenia layoutów i efektów na stronie`,`Biegle posługiwać się kluczowymi właściwościami CSS`],
   
  },
  {
    authors: ['Bartłomiej Borowczyk'],
    id: uuid(),
    img: 'https://img-c.udemycdn.com/course/240x135/1916892_601a.jpg?Expires=1624950943&Signature=kQqNtQFRv~D4S5wgGsgoPBQ--KMqE3F-eHWFU2SAG6oGm5VCgsqL1QGn3oQFYrSR-PEboHxwuRERwUdSLQVsUjNgCk2dh5t-eHmHqQJY6BPvPIVRLV531crgg-3hu4xzvJbkYqCxT2ywjbHL-DclTRocVe799PNEYXfSSmVxM9fDb2HgXnHE6SMlI0ER8QzpvwELjUfCoAudLC02cM-dkYytuBXu77UW6HnkorZasKqBqs42Tu3zYloyG3hCNWayCuTDTaBJI--iI0cDx-QyjltDal9UzwDgPKACwkYQLYRi817n4FxQsp~bd11xlnmjNwD7KbIE8W7MBgggvtMuNA__&Key-Pair-Id=APKAITJV77WS5ZT7262A',
    price: 69.99,
    language: 'Polski',
    date: '02.2019',
    title: 'Programowanie w JavaScript',
    level: 'Zaawansowany',
    hours: 72,
    lectures: 290,
    shortDiscription: `Od podstaw do programowania zorientowanego obiektowo`,
    description: [`W trakcie tego kursu nauczysz się programować w JavaScript, co ułatwi Ci pracę ze stroną internetową, ale też późniejsze wejście w świat React czy Node. Oczywiście, będziemy programować w oparciu o najnowsze standardy, poznasz JavaScript w wersji ES5 i ES6.`

    ,`Kurs rozpoczyna część teoretyczna, przy czym będzie to podstawowa wiedza, która jest niezbędna, by poznać język JavaScript i sprawnie się nim posługiwać. Omawiam tu kluczowe pojęcia związane z programowaniem i JavaScript, jak typy danych, zmienne, instrukcje warunkowe, funkcje, tablice, obiekty, zakresy, operatory, hoisting, pętle oraz DOM. Zakładam, że dla części uczestników kursu, choćby tych, którzy uczyli się ze mną na moim kanale na YT, nie będą to nowe zagadnienia. Jeśli znasz fundamenty JS, to będzie to dla Ciebie powtórka i usystematyzowanie wiedzy. Jeśli jednak uczysz się od podstaw, będziesz musiał skupić się mocno na omawianych treściach. Staram się zawrzeć tu takie must know, bez zagłębiania się, ale na pewno będzie to solidna podstawa do dalszej nauki.`

    ,`Po części teoretycznej napiszemy kilkanaście projektów, które pozwolą Ci wytrenować umiejętność programowania i utrwalić znajomość JavaScript. Wśród tych projektów znajdziesz zegar (także czasomierz oraz odliczanie czasu do końca), baner (sterowany klikiem i klawiszami), proste gry (nożyczki-papier-kamień oraz jednoręki bandyta) oraz listę zadań (dodawanie, przeszukiwanie). Oczywiście wiele z tych projektów będzie zadaniami dla Ciebie do samodzielnego wykonania, przy czym po zrobieniu zadania możesz zobaczyć moje rozwiązanie.`

    ,`Trzecia część kursu dotyczy programowania zorientowanego obiektowo (object-oriented programming). Jest to podejście inne od podstawowego (proceduralnego) programowania, które poznasz w pierwszych dwóch częściach tego kursu. Przekażę Ci teorię OOP, ale także wykonamy praktyczny projekt.`

    ,`Kurs jest trzecim etapem projektu "Od podstaw do pierwszej pracy jako front-end developer". Jest to bardzo ważny krok w tym projekcie, ponieważ rzeczy, których się w nim nauczysz - umiejętność programowania, znajomość JavaScript i programowania obiektowego - będą podstawą nauki w kolejnym etapie, czyli w kursie React. Dla osób, które chcą wejść bardziej w świat programowania niż front-endu, tworzyć aplikacje, będzie on dobrym punktem startowym (przy czym zaznaczam, że podstawowa wiedza o HTML i CSS jest potrzebna, by z niego korzystać).`

    ,`Zastosowanie JavaScript we front-endzie do tworzenia layoutów i efektów na stronie omawiałem w 2. etapie - kursie "Front-end zaawansowany w 15 dni". W tym kursie mam nadzieję nauczyć Cię nie tylko języka JavaScript, ale też sprawić, byś polubił(a) programowanie. Wiedza i umiejętności nabyte po kursie przydadzą Ci się nawet, jeśli wiążesz swoją przyszłość z front-endem i nie zamierzasz zajmować się programowaniem back-endowym.`],
    knowledge: [`Znajomość JavaScript w wersji ES5 i ES6`, `Znajomość podstaw programowania zorientowanego obiektowo (object-oriented programming)`, `Umiejętność programowania proceduralnego w JavaScript`, `Czerpanie przyjemności i satysfakcji z programowania :)`]
  },
  {
    authors: ['Bartłomiej Borowczyk', 'Mateusz Domański'],
    id: uuid(),
    img: 'https://img-c.udemycdn.com/course/240x135/2049385_9a8c.jpg?Expires=1624951047&Signature=kiirGBi9tt1d3zex03eS7Sql0lGJbD~VZx1p-jwqicaUfiQ6VToj4WuMXnxPnCKLDqJOs7mcgh~q3~CSgT4eSofTlA1XqJDfJcZhTY5Eq~EWzQuEjrJ4YgVH1sAm55wT8AORdPH9ZFldb9cMVQSAel1-wICEQeNaoNK3-tDGiXYlyQYwFBF2ENpdCeTbuFUyCxST1eJmuwQnByy9NbMqI1uAs~MA6i70d42kWGuVo5LyHgXZtL4GOmRC9GJ0nnWktsCW4G5j5z1IsxQg3ZGLqwmVagPiJo4NnNiRcaJmYZNE2FZWOvLqzgm1pMvICKmUncKWKjkzphKfmCy5jB-c8w__&Key-Pair-Id=APKAITJV77WS5ZT7262A',
    price: 69.99,
    language: 'Polski',
    date: '01.2021',
    title: 'React od podstaw',
    level: 'Podstawowy',
    hours: 64,
    lectures: 170,
    shortDiscription: `Teoria i praktyka`,
    description: [`Biblioteka React to jedno z najpopularniejszych rozwiązań w pracy front-end developera.  React to nowe podejście do tworzenia interfejsów użytkownika. Ten kurs ma dać Ci mocne fundamenty teoretyczne, ale także, poprzez wiele przykładów, nauczyć cię praktycznego wykorzystania React. To nie jest chwilowa moda czy przypadek, że mnóstwo ogłoszeń o pracę na stanowisku front-end developera wymaga znajomości Reacta. Jeśli poznałaś/poznałeś już JavaScript, to kolejnym krokiem w Twojej nauce może być React.`

    ,`UPGRADE 09.2020 - kilkanaście godzin materiałów dogranych przez Mateusza Domańskiego: Hooki, React Context, Redux, MobX czy TypeScript (mini kurs). A na deser projekt w którym tworzymy front (React) i backend aplikacji.`

    ,`W kursie uczę biblioteki React od podstaw, jednak od uczestnika wymagam już podstaw HTML i CSS oraz podstawowej znajomości JavaScript. W pierwszej fazie kursu przypomnę najważniejsze koncepcje JS, które często pojawiają się podczas pisania aplikacji w React, takie jak klasa, dziedziczenie, funkcja strzałkowa, sposoby pracy na tablicy i mechanizm this.`

    ,`Jeśli nie czujesz się mocna/mocny w JS, to przed rozpoczęciem nauki React zapraszam Cię do mojego kursu Programowanie w JavaScript. Pamiętaj, że React to biblioteka JavaScript.`

    ,`Kurs jest skierowany do osób, które nie mają żadnego doświadczenia w pracy z biblioteką React lub poznali ją, ale jedynie bardzo powierzchownie.`],
    knowledge: [`Znajomość biblioteki React w stopniu, który pozwoli Ci z niej korzystać i ubiegać się o pracę tam, gdzie jest ona wymagana`, `Tworzyć Single Page Application (w warstwie widoku)`]
  },
  {
    authors: ['Bartłomiej Borowczyk'],
    id: uuid(),
    img: 'https://img-c.udemycdn.com/course/240x135/2330558_0de2_2.jpg?Expires=1624951307&Signature=c-y--vtWytLlZqR~nA2ihEoXTHa7DW2l8b~Lo7uAr1nVZxgR098NO6ELtP6vCrhQ1lYGaDSDAnrGq6d5dmAE8qr9HhzGDUOesisUWTW-AASdd4EgjiHJG9~E0K~zkPgkW~rX6RdBPNwExasOQNGW9x~B3sNfH3jEjKQcjbOTqIb6aa2a2oOx1T6pS5Ix~qaJhvKP7bQZfbP8IcRbhfXigkPmRA-2zWz~2F4KzPG7gRIJZe-4hAKvj8xQHzp636VyBVqrdow7A0lED2L8-CQ2egDQNVXBGlENbtm5JgsdEpwCBmQ9MIPargOl4VB51~MJcNLNVDnYrg4HOkkUxKMi8Q__&Key-Pair-Id=APKAITJV77WS5ZT7262A',
    price: 69.99,
    language: 'Polski',
    date: '03.2019',
    title: 'Backend - Node.js, Express i MongoDB',
    level: 'Zaawansowany',
    hours: 44,
    lectures: 214,
    shortDiscription: `dla osób, które chcą poznać platformę Node.js, bazę danych MongoDB oraz framework Express`,
    description: [`Masz ochotę lub potrzebę poznać Node.js, MongoDB i Express? Świetnie, ten kurs Ci w tym pomoże.`

    ,`Dla kogo jest ten kurs?`

    ,`Kurs tworzyłem z myślą o początkujących i średniozaawansowanych front-end developerach. Dlaczego? Bardzo wielu front-end developerów musi (wymaga od nich tego praca lub coraz trudniejsza rekrutacja) opanować w pewnym stopniu technologie back-endowe, czyli programowanie po stronie serwera oraz bazy danych.`

    ,`Przy okazji tego odkrywania back-endu często okazuje się, że tworzenie aplikacji sieciowych (po stronie serwera) staje się drugą nogą front-end developera i idzie on w kierunku full-stack developera, czyli ogarniacza zarówno kwestii frontu i back-endu. Inna sprawa, że nawet jeśli taki front-end developer w przyszłości nie będzie się do back-endu dotykał, to wiedza o tym, jak to działa, uczyni go lepszym front-end developerem.`

    ,`Ten kurs jest skierowany do osób, które znają JavaScript, ale nie znają Node.js, MongoDB i Express.  Jeśli znasz już MongoDB i Express, to nie trać czasu na ten kurs, wybierz coś bardziej zaawansowanego.`

    ,`Uczymy się Node.js, MongoDB i Express - czyli jesteśmy w świecie JavaScript`

    ,`No właśnie, ten kurs nie uczy JavaScript od podstaw, zakładam, że na tym etapie wiesz już, co to zmienne, scope, ES6, funkcja strzałkowa czy klasy. Nie musisz wymiatać, ale posługiwać się tymi elementami języka JavaScript powinieneś. Jeśli czujesz, że masz tu duże braki lub któreś z przytoczonych pojęć jest Ci obce, to przed przystąpieniem do tego kursu, w Twoim interesie, popracuj nad swoim JavaScriptem. Polecam przy tym mój kurs o JavaScript na Udemy (ale możesz uczyć się z dowolnego miejsca i w dowolny sposób - ważne, by skutecznie i przyjemnie).`

    ,`Jeśli jeszcze nie pracujesz...`

    ,`... i uczysz się ze mną w ramach sześciu etapów-kursów dostępnych na Udemy, to ten kurs stanowi 5. etap mojego programu. Po tym kursie staniesz się lepszym programistą i uzyskasz kolejny istotny argument w drodze do swojej pierwszej pracy jak front-end developer.`

    ,`Jeśli pracujesz jako początkujący front-end developer (staż lub junior) ...`

    ,`... to zapewne masz potrzebę lub chęć, by rozwijać się w tym kierunku. Ten kurs będzie dla Ciebie dobrym wprowadzeniem w back-end.`

    ,`Czym jest Node.js, MongoDB i Express`

    ,`- Node.js - środowisko uruchomieniowe dla JavaScript po stronie serwera. Pisze programy, które uruchamiasz już nie tylko w przeglądarce. Dzięki Node.js JavaScript stał się  uniwersalnym językiem programowania i jednym z najpopularniejszych (prawdopodobnie najpopularniejszym)`

    ,`- MongoDB - najpopularniejsza nierelacyjna (NoSQL) baza danych, bardzo popularna wśród programistów tworzących aplikacje w Node.js`

    ,`- Express - najpopularniejszy framework Node.js do tworzenia aplikacji webowych (pełni podobną rolę jak Laravel w PHP, Spring w Java, Django w Pythonie czy Ruby on Rails w Ruby)`

    ,`Jak wygląda kurs`

    ,`Pierwsza część kursu, będąca wprowadzeniem w świat Node.js, jest prowadzona przeze mnie (Bartek Borowczyk). Ten etap ma na celu pokazać Ci, czym Node.js jest, w jaki sposób działa i jak go używać. Na tym etapie będą też dwa proste projekty w wierszu poleceń oraz sekcja serwer HTTP, która pokaże Ci na czym polega komunikacja między serwerem a klientem za pomocą protokołu TCP/IP i protokołu HTTP. Oprócz tego skonstruujemy przykładowe (proste) aplikacje serwerowe w Node.js.`

    ,`Następnie przejdziemy do nauki Express. Sekcję tę poprowadzi Jakub Król, świetny programista, ale też rewelacyjny i doświadczony wykładowa, który najpierw zrobi wprowadzenie do Express i jego najważniejszych metod, a następnie pokaże jak stworzyć aplikację backendową w Express i jak zintegrować ją z frontem.`

    ,`Trzecia część kursu to projekt Bartka Kaczora, świetnego programisty JavaScript i Node.js, który, stosując własne praktyki i przyzwyczajenia, stworzy projekt będący sporym wyzwaniem dla osób, która niedawno zaczęła się Node.js, Express i MongoDB uczyć.  Stworzymy prosty serwis typu CMS oraz umieścimy go w chmurze Heroku.`

    ,`Wreszcie na deser, już nie jako główny rdzeń kursu, a raczej bonus (dla chętnych), otrzymasz materiał poświęcony testom automatycznym w Node.js. Poprowadzi go Rafał Ruciński.`

    ,`Reasumując`

    ,`Kurs jest wprowadzeniem (dotyczy podstaw i jest od podstaw) w świat back-endu z wykorzystaniem języka JavaScript. Uczysz się trzech topowych technologii web developmentu, na które jest (i będzie) wielki popyt na rynku pracy. Ale zdobywasz też umiejętności, które w przyszłości mogą Ci pozwolić tworzyć własne serwisy, sklepy internetowe, aplikacje mobilne. Wszystko to, i wiele więcej, jest możliwe z użyciem między innymi trzech technologii, które już za chwilę możesz poznawać w tym kursie.`

    ,`Jeśli nadal nie jesteś pewna/pewny, czy to dla Ciebie, obejrzyj kilka pierwszych darmowych lekcji.`

    ,`Zapraszam i do zobaczenia! :)`

    ,`Samuraj Programowania (Bartek Borowczyk)`

    ,`PS.  W najbliższych czasie (lipiec) kurs będzie jeszcze uzupełniony o materialy o MongoDB.`],
    knowledge: [`poznać podstawy back-endu`,`tworzyć zaplecze serwerowe, wykorzystując JavaScript`,`korzystać z nierelacyjnych baz danych MongoDB`,`korzystać z API platformy Node`,`tworzyć serwisy webowe z użyciem frameworka Express`]
  },
  {
    authors: ['Bartłomiej Borowczyk'],
    id: uuid(),
    img: 'https://img-c.udemycdn.com/course/240x135/2331806_b90c_2.jpg?Expires=1624951376&Signature=FNVMfB9bmxMLF4WYQ6SAFdw-uOcNE5IjViEE7S-pANOIUox2bddmqVoUl8Hkc9Hly2~gaF0e47aGiFzf9JHJScX0rzxrjMxX1pgq4RxU9tj4czXcknEuQerZxxWdfZ~45UOsyc8lnhFdN0srrfaZy8m6CfQqfDsY1T1HpUJrzH9D7utoCgPkgAVBt7iolkBTRpCWmiiyJinGF8o01Wo5EF~OUTwiR2eAbFxqiv-PWodFVNJKzwTe07y35U~nnpz5XTQjb49ONrogaTUFUtm25NhJRGIXg669Os-GjG9LPkh4o-G771~jO12snPbJMrCEFzMHNQ89MfIMFfiPKvxX3w__&Key-Pair-Id=APKAITJV77WS5ZT7262A',
    price: 69.99,
    language: 'Polski',
    date: '11.2020',
    title: 'Zaawansowane Projekty w CSS i JavaScript',
    level: 'Średnio-zaawansowany',
    hours: 52,
    lectures: 132,
    shortDiscription: `7 projektów + BEM + Sass + Node.js + npm + JavaScript + webpack + Bootstrap + animacje + responsywność i optymalizacja`,
    description: [`Dzień dobry! Dziękuję za zainteresowanie kursem "Zaawansowane projekty w CSS i JavaScript". Ten kurs to nie tylko ciekawe projekty, ale także technologie i umiejętności wychodzące znacznie poza podstawy HTML, CSS i JavaScript. Poniżej znajdziesz najważniejsze informacje o kursie. Zapraszam do wspólnej nauki!`

    ,`CZEGO UCZYSZ SIĘ W TYM KURSIE`

    ,`- BEM - bardzo popularna metodologia, w której części naszego interfejsu dzielimy na bloki i elementy a wariacje obu definiujemy za pomocą modyfikatorów. BEM może sprawiać na początku wiele problemów a dla części osób może być nieintuicyjny. Pokażę Ci, że to naprawdę ciekawy sposób myślenia o UI oparty na oryginalnym podejściu do tworzenia klas i selektorów. Jestem przekonany, że w swojej karierze front-end developera spotkasz się i będzie musiał(a) - mam nadzieję, że także chciał(a) - korzystać z BEM. Dlatego warto już dziś go poznać :)`

    ,`- Sass - najpopularniejszy (A.D. 2020) preprocesor CSS. Preprocesor rozszerza możliwości CSS-a i jest technologią "must know" dla front-end developera. Korzystanie z Sass wymaga od Ciebie poznania składni nowego metajęzyka - języka będącego rozszerzeniem CSS. Oczywiście CSS jest procesem końcowym pracy z Sass a ostatnim etapem tej pracy jest kompilacja Sass na CSS (zobaczysz też różne jej sposoby). W tym kursie poznasz najważniejsze koncepcje Sass oraz korzyści z ich używania. Będzie teoria oraz praktyka. Zobaczysz też, że Sass bardzo fajnie komponuje się z wcześniej poznanym BEM.`

    ,`- Flexbox i CSS Grid - najnowsze i najpopularniejsze obecnie techniki CSS pozwalające tworzyć layout strony i rozmieszczać elementy w kontenerach. W kursie skupiamy się przede wszystkim na CSS Grid, zakładam bowiem, że Flexbox udało Ci się już poznać (choćby z jednego z moich wcześniejszych kursów). Jeśli potrzebujesz dobre powtórki Flexboxa i dobrego opracowania CSS Grid z przykładami, to trafiłeś/-aś idealnie :)`

    ,`- JS i DOM - Zakładam, że JavaScript znasz co najmniej w stopniu podstawowym.  W tej części będzie przede wszystkim o korzystaniu z JavaScript w pracy z DOM oraz o korzystaniu z API (AJAX). Znajdzie się też czas na wyjaśnienie relacji między przeglądarką a serwerem. Ten kurs to także wyjaśnienie modułów w Javascript i to zarówno w specyfikacji CommonJS jak i ES Modules - od tego się nie ucieknie w bardziej zaawansowanych projektach.`

    ,`- Node.js i NPM - niezbędne wprowadzenie dla front-end developera. Jeśli robiłeś/-aś już bardziej zaawansowane rzeczy po stronie frontu (np. korzystałeś/-aś z React.js) lub uczyłeś/-aś się back-endu, to znasz już Node.js i NPM. Jeśli tak jest, będzie to dla Ciebie w dużej części przypomnienie, jeśli nie, to dowiesz się istotnych rzeczy, z których z pewnością przyjdzie Ci korzystać, jeśli będziesz rozwijać karierę front-end developera. Znajomość Node i NPM profesjonalizuje i przyspiesza naszą pracę.`

    ,`- Webpack - świetne i popularne środowisko developerskie. Dzięki webpackowi możliwy jest bundling (JS,CSS, grafiki, HTML) i automatyzacja zadań (np. kompilator Sass, transpilacja do ES5, minifikacja i optymalizacja) czy użycie serwera deweloperskiego. Będę starać się dobrze Ci wytłumaczyć działanie Webpacka, a nie tylko pokazać, jak go skonfigurować na zasadzie kopiuj - wklej.`

    ,`- Animacje - strona bez animacji? Nawet w XX wieku były już gify :) A tak poważnie, animacje mają olbrzymi wpływ na estetykę strony, ale także na interfejs i bardzo pomagają uczynić stronę przyjazną (zrozumiałą) i atrakcyjną dla użytkownika. Skupimy się na animacjach w CSS, ale użyjemy też JavaScript.`

    ,`- SVG i GSAP - grafika wektorowa w niektórych sytuacjach jest świetnym rozwiązaniem przy tworzeniu strony  Skalowalne (dobre na każdy wyświetlacz), małe, powszechnie wspierane w przeglądarkach, bardzo dobre do animacji i interakcji - nie dziwi więc, że takie grafiki są często spotykane. W kursie poznasz też podstawy pracy z jedną z najpopularniejszych bibliotek do animacji (także animacji SVG), którą jest GSAP (Green Sock Animation Platform).`

    ,`- Responsywność - optymalizacja - dostępność - jak tworzyć strony, które są wydajne, mają zoptymalizowane zasoby, są szybkie i da się z nich korzystać na różnych urządzeniach, różnych rozdzielczościach i różnych przeglądarkach. To jest temat rzeka i nie ogranicza się tylko do Media Queries i podejścia mobile first. My się z tym zagadnieniem zmierzymy na poważnie.`

    ,`- BONUS: Bootstrap (gość) - Bootstrap to framework do tworzenia interfejsów użytkownika. W praktyce Bootstrap pozwala tworzyć responsywne strony w oparciu o gotowe elementy interfejsu i zdefiniowane style - nie trzeba wszystkiego pisać od zera. Bootstrapa można kochać i używać albo i nie. Ale warto go poznać.`

    ,`A oprócz tego aż 7 zaawansowanych projektów z wykorzystaniem CSS i JavaScript - jeden tworzony przez mnie i 6 tworzonych przez zaproszonych gości.`

    ,`GOŚCIE W KURSIE`

    ,`W tym kursie część materiałów została przygotowana przez gości. Zostało to zaznaczone w harmonogramie. Dzięki gościom poznasz styl pracy kilku front-end developerów, co stanowi wartość dodaną tego kursu.`

    ,`Zapraszam!`],
    knowledge: [`Preprocesor Sass`, `Flexbox i CSS Grid`, `JS i DOM`, `tworzenie animacji w CSS i JS`, `tworzenie zaawansowanych projektów w CSS i JavaScript`,`Metodologia BEM`,`Node i NPM`,`Webpack`,`Bootstrap`,`tworzenie stron wydajnych, zoptymalizowanych i dostępnych na wielu urządzeniach i rozdzielczościach`]
    
  },
  {
    authors: ['Bartłomiej Borowczyk'],
    id: uuid(),
    img: 'https://img-c.udemycdn.com/course/240x135/2258904_bd66_4.jpg?Expires=1624951216&Signature=IUbj6zQCT7bHFfqxETkSCnE6MCPGZBcnNGEsH69LjkLfIUy0MoWv8gRAQmJJSPoZvPkv5267efM~kyPXodv~5ENPmWGfdVYGSx33IuTnaX4-bPJCpkMs3YNCrjeWf2p0YaZtHdCvjnMnEtmJhSdxfVS5lYITgPNCsb8QGcsSJpjieMPsaudirmEpyI6i29mXgJp9Eh7iot4AbGjwc4YCBfs~vI2bPzzHrjQRU7mmAzLJ9-PD9ofaQzZStnsP~HvHM5e03VL5Eh0uaW2KPjJCZ2TrjRXymuiJZv~~8Mh6grFb8-LYww4-zcVdKHu-g5ATrbqvTialSw9L54gqp2UiqA__&Key-Pair-Id=APKAITJV77WS5ZT7262A',
    price: 0,
    language: 'Polski',
    date: '05.2020',
    title: 'Wprowadzenie do Git i GitHub',
    level: 'Podstawowy',
    hours: 12,
    lectures: 50,
    shortDiscription: `Tylko dla osób, które nie znają Gita. Podstawy najpopularniejszego systemu kontroli wersji`,
    description: [`System kontroli wersji jest bardzo przydatny w pracy programisty czy web developera (do tworzenia kopii zapasowej, zapisania różnych wersji projektu) a w przypadku pracy w zespole nieodzowny. Git jest najpopularniejszym, darmowym systemem, dlatego warto go poznać. Ten kurs jest kursem od zera dla osób, które nie korzystały jeszcze z Gita i platformy GitHub i obejmuje jedynie fundamenty, które pozwolą zacząć korzystać z Gita i GitHuba we własnych projektach oraz przy współpracy z innymi w zespole. Dowiesz się, czym jest Git i jak go używać w podstawowym zakresie, nauczysz się też korzystać z platformy GitHub do pracy z repozytoriami. Poznasz interpretery wiersza poleceń (PowerShell i Git Bash), dowiesz się jak publikować projekty na GitHub Pages a także zintegrować Git, GitHub i Visual Studio Code.`

    ,`Kurs jest darmowy.`],
    knowledge: [`Czym jest Git i jak go używać`, `Korzystać z platformy GitHub - w tym tworzyć repozytorium, umieszczać je czy klonować`,`Korzystać z interpretera poleceń (PowerShell i Git Bush)`,`Zintegrować GitHub z Visual Studio Code`,`Umieszczać projekt na GitHub i GitHub Pages`]
  },
  {
    authors: ['Bartłomiej Borowczyk', 'Mateusz Domański', 'Michał Dziedziński', 'Kacper Sieradziński'],
    id: uuid(),
    img: 'https://img-c.udemycdn.com/course/240x135/3428814_eee3_4.jpg?Expires=1624952923&Signature=ewpsB-UAGbGvt6tcxZ~ro1GTgzcCFUsI0~XN63sQNO44W2jO26jpvsH3vnlg8BvSAvpw07jacmdB91wMXmzRwRyrn9VmBNqEidT3uBsB4hxqAtk8PDysnufpukAEgZGsl1maRp4L96eGxoaQ6PEX9Rmfym-SXnTY4bF5fpZpBhE3UdGBHH3UnhHbhkU67YYLjYeZfvsR6yfeOqLQdhvUu6B5J~D6u5jZyp7d2klD-K6eq8uIWrRaNMt5zh6cP3vTpGzUKlmW79j~gBMoENoLob4Cnf-6nMuXvivnr5ScAz~5zp2K1CRxeNqLrWECiP4nwRY9QlJotEcPTa36tFyyZw__&Key-Pair-Id=APKAITJV77WS5ZT7262A',
    price: 99.99,
    language: 'Polski',
    data: '08.2018',
    title: 'Nauka JavaScript - obiektowość',
    level: 'Zaawansowany',
    hours: 85,
    lectures: 390,
    shortDiscription: `6 gier w JavaScript - osiągnij wyższy poziom programistyczny i świetnie się przy tym baw!`,  
    description: [`Ten kurs to nauka programowania w JavaScript na poziomie średnio zaawansowanym w połączeniu ze świetną zabawą. Na uczestników kursu czeka aż 6 projektów gier, trzech doświadczonych prowadzących i ponad 25 godzin materiałów.`

    ,`Ten kurs nie ma na celu zrobić z Ciebie game developera (choć może zainspiruje Cię do tego)! Ten kurs ma na celu zrobić z Ciebie świetnego programistę JavaScript, który rozumie i umie korzystać z technik programowania obiektowego i umie modelować program w oparciu o klasy i obiekty oraz relacje między nimi (słowo klucz tutaj to kompozycja). A tworzenie gier jest wyjątkowo dobrym sposobem na uczenie się programowania obiektowego, ponieważ każda z nich to wyjątkowy świat i wyjątkowe problemy.`

    ,`W ramach kursu stworzysz wspólnie z prowadzącymi aż 6 popularnych niegdyś gier, którymi możesz potem zasilić swoje portfolio projektów w JavaScript:`

    ,`Wisielec`

    ,`Saper`

    ,`Diamonds`

    ,`Blackjack`

    ,`Spaceship`

    ,`Arkanoid`

    ,`Wielkim plusem tego kursu są także prowadzący. Każdy z nich zwróci Ci uwagę na istotne, często różne elementy. Każdy z nich oprze też swoje projekty na indywidualnych doświadczeniach.`

    ,`Ten kurs to praktyka, praktyka i jeszcze raz praktyka, jednak wszystko jest oczywiście tłumaczone, tak by udało Ci się to zrozumieć i korzystać z nabytych umiejętności w praktyce.`

    ,`Jako bonus, w pierwszej sekcji, każda osoba, dla której programowanie obiektowe jest czymś nowym, otrzyma wprowadzenie w świat klas, konstruktorów oraz obiektów. Oprócz tego dowiesz się też (a później oczywiście jeszcze uzupełnisz tą wiedzę w projektach gier), czym jest hermetyzacja (klasy, metody i właściwości prywatne - różne techniki), dziedziczenie (extends i prototype), polimorfizm, abstrakcja i kompozycja (relacje między obiektami).`

    ,`Na rynku brakuje kursów o programowaniu obiektowym w JavaScript, a szczególnie dotyczy to praktyki. Ten kurs jest tym, czego potrzebujesz, jeśli chcesz nauczyć się nie tylko, czym jest programowanie obiektowe (OOP), ale także jak programować obiektowo.`

   ,` W imieniu swoim oraz Michała Dziedzińskiego, Kacpra Sieradzińskiego i Mateusza Domańskiego zapraszam!`

    ,`Ps. ten kurs ma sens, jeśli będziesz pisał kod równolegle z nami, nie ograniczaj się do oglądania, bo to nie ma sensu :)`

    ,`Bartek Borowczyk aka Samuraj Programowania`],
    knowledge: [`programowanie w JavaScript na poziomie średnio zaawansowanym`, `programowanie zorientowane obiektowo (OOP)`]
  }
];

exports.getCourses = (request, response, next) => {
  try {
    response.status(200).json({
      courses: coursesData
    });
  } catch (error) {
    response.status(500).json({
      error,
      message: 'Oops! Coś poszło nie tak, przy metodzie GET w endpointcie /courses',
    });
  }
};

exports.getCourse = (request, response, next) => {
  try {
    const { id } = request.params;
    const courseToSend = coursesData.find(course => course.id === id);

    if (!courseToSend) {
      response.status(404).json({
        message: 'Nie znaleziono kursu o podanym id',
      });
      
      return;
    }

    response.status(200).json({
      course: courseToSend, 
    });
  } catch (error) {
    response.status(500).json({
      error,
      message: 'Oops! Coś poszło nie tak, przy metodzie GET w endpointcie /courses/:id',
    })
  }
};

exports.postCourse = (request, response, next) => {
  try {
    const { authors, id, price, title, img, date, level, hours, lectures, shortDiscription, description, knowledge, language} = request.body;
    if ( !authors || !id || !price || !title || !img || !date || !level || !hours || !lectures || !shortDiscription || !description || !knowledge || !language) {
      response.status(400).json({
        message: 'Nie podano wszystkich wymaganych informacji',
      });

      return;
    }

    const isCourseExist = coursesData.some(({title: currentTitle}) => currentTitle === title);
    if (isCourseExist) {
      response.status(409).json({
        message: `Istnieje już w bazie kurs ${title}`,
      });

      return;
    }

    const newCourse = {
        authors: authors,
        id: uuid(),
        img,
        price,
        title,
        img, 
        date, 
        level, 
        hours, 
        lectures, 
        shortDiscription, 
        description, 
        knowledge,
        language
    };

    coursesData.push(newCourse);

    response.status(201).json({
      courses: coursesData
    });
  } catch (error) {
    response.status(500).json({
      error,
      message: 'Oops! Coś poszło nie tak, przy metodzie POST w endpointcie /courses'
    });
  }
};

exports.putCourse = (request, response, next) => {
  try {
    const { authors, id, price, title, img, date, level, hours, lectures, shortDiscription, description, knowledge, language } = request.body;
    if (!authors || !id || !price || !title || !img || !date || !level || !hours || !lectures || !shortDiscription || !description || !knowledge || !language) {
      response.status(400).json({
        message: 'Nie podano wszystkich wymaganych informacji',
      });

      return;
    }

    const indexCourseToUpdate = coursesData.findIndex(course => course.id === id);
    if (indexCourseToUpdate === -1) {
      response.status(404).json({
        message: 'Nie znaleziono kursu o podanym id',
      });
      
      return;
    }
    
    
    coursesData.splice(indexCourseToUpdate, 1, request.body);

    response.status(202).json({
      courses: coursesData
    });
  } catch (error) {
    response.status(500).json({
      error,
      message: 'Oops! Coś poszło nie tak, przy metodzie PUT w endpointcie /courses'
    });
  }
};

exports.deleteCourse = (request, response, next) => {
  try {
    const { id } = request.params;
    const indexCourseToDelete = coursesData.findIndex(course => course.id === id);

    if (indexCourseToDelete === -1) {
      response.status(404).json({
        message: 'Nie znaleziono kursu o podanym id',
      });
      
      return;
    }

    coursesData.splice(indexCourseToDelete, 1);
    response.status(200).end();
  } catch (error) {
    response.status(500).json({
      error,
      message: 'Oops! Coś poszło nie tak, przy metodzie DELETE w endpointcie /courses/:id',
    });
  }
};

exports.coursesData = coursesData;